﻿Public Interface DiseaseCases
    Property Cases(i As Integer) As Integer
    ReadOnly Property TotalCases() As Integer
    Function AvgCases() As Double

End Interface
