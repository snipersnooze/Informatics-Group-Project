﻿Public Interface DiseaseCases
    'Gives the Threat Level in that particular region
    Function Details() As String
    'Gives the Symptoms of the Disease
    Function Symptoms() As String
End Interface
