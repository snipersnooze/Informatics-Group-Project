﻿Option Strict On
Option Explicit On
Option Infer Off

Public Class Malaria
    'Inherits Base Class Disease
    Inherits Disease
    'Implements the Interface
    Implements DiseaseCases
    'Variables
    Private _Nets As Integer
    Private _Mosquito As Integer
    Private _Area As Double
    Private _KlWater As Double

    'Constructor
    Public Sub New(Months As Integer, Cases As Integer, Mosquito As Integer, Area As Double, Water As Double, Nets As Integer)
        MyBase.New(Months, Cases)
        _Mosquito = enforceRange(Mosquito)
        _Area = enforceRange(Area)
        _KlWater = enforceRange(Water)
        _Nets = enforceRange(Nets)
    End Sub

    'Method
    'Recovery Rate
    Public Function RecoveryRate() As Double
        Dim Value As Double
        Value = (((_Nets * _Area) - (_Mosquito * _KlWater)) / TotalCases) * 100
        If Value >= 0 And Value <= 100 Then
            Return Value
        Else
            Return 0
        End If
    End Function
    'Details - Gives threat Level
    Public Function Details() As String Implements DiseaseCases.Details
        If RecoveryRate() >= 0 And RecoveryRate() <= 25 Then
            Return "Extreme Level Threat!"
        ElseIf RecoveryRate() > 25 And RecoveryRate() <= 50 Then
            Return "High Level Threat!"
        ElseIf RecoveryRate() > 50 And RecoveryRate() <= 90 Then
            Return "Medium Level Threat!"
        Else
            Return "Low Level Threat!"
        End If
    End Function
    'Symptoms Of Malaria
    Public Function Symptoms() As String Implements DiseaseCases.Symptoms
        Return "Symptoms of Malaria: " + Environment.NewLine + "-> Fever and Fatigue." _
                                       + Environment.NewLine + "-> Nausea and vomiting." _
                                       + Environment.NewLine + "-> Headache and Muscle Pain." _
                                       + Environment.NewLine + "-> Chills, Shivering and Sweating."
    End Function
End Class
